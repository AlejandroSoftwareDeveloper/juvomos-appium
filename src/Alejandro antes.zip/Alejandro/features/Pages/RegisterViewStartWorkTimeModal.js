
const JUVO               = "id:com.juvomos.pos:id/"
const BTN_POS            = JUVO + 'btnPos'
const BTN_TIME_CLOCK     = JUVO + 'btnTimeClock'
