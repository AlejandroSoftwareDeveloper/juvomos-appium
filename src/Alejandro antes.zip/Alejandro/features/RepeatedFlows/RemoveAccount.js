

class RemoveAccount{


}

export default new RemoveAccount()
