

// Pending 
class WalkerBot {
    constructor(){
        this.pages = []
    }

}

export default new WalkerBot()
